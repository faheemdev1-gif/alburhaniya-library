#!/usr/bin/env python3
"""
Build library.db (SQLite + FTS5) from data/raw_htm (or data/raw_utf8) +
data/mapping.json + data/sources.json.

Runs once, at Docker build time, so the shipped image already contains a
ready-to-query search index. No persistent disk needed: every fresh
deploy rebuilds this file from the book sources baked into the image.

Source grading (added):
  data/sources.json carries, for every book_id, its source grade
  (أصلي / ثانوي) plus author + a short book-specific note. The long
  boilerplate definition of each grade is stored ONCE in the `grades`
  table — not repeated per book, and NEVER written into `pages`, which
  would pollute the FTS index with 43 identical copies of high-value
  words like العقيدة / المشايخ / سيدي الإمام فخر الدين.

Two source formats (added):
  Most books are shamela.ws .htm exports (windows-1256), parsed by
  parse_book(). Some books use modern Unicode that windows-1256 can't
  represent at all (e.g. the ﷺ ligature, Quranic ornate brackets ﴿ ﴾,
  Arabic-Indic digits) — those live as pre-segmented UTF-8 JSON in
  data/raw_utf8/ instead, parsed by parse_utf8_pages(). Both return the
  same {"printed_page", "paragraphs"} shape, so everything downstream
  (DB insert, FTS indexing) is identical either way.
"""
from __future__ import annotations
import json
import os
import sqlite3
import sys
import re

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app", "core"))
from book_parser import parse_book, parse_utf8_pages, split_oversized_pages   # noqa: E402
from arabic_utils import normalize_arabic             # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, "..", "data")
RAW_DIR = os.path.join(DATA_DIR, "raw_htm")
RAW_UTF8_DIR = os.path.join(DATA_DIR, "raw_utf8")
MAPPING_FILE = os.path.join(DATA_DIR, "mapping.json")
SOURCES_FILE = os.path.join(DATA_DIR, "sources.json")
DB_PATH = os.environ.get("LIBRARY_DB_PATH", os.path.join(HERE, "..", "library.db"))

SCHEMA = """
CREATE TABLE grades (
    grade       TEXT PRIMARY KEY,   -- 'أصلي' | 'ثانوي'
    code        TEXT NOT NULL,      -- 'primary' | 'secondary'
    label       TEXT NOT NULL,
    definition  TEXT NOT NULL,      -- the Arabic boilerplate, stored ONCE
    usage       TEXT NOT NULL       -- how a model should weigh it
);

CREATE TABLE source_tiers (
    tier        INTEGER PRIMARY KEY CHECK (tier BETWEEN 1 AND 5),
    definition  TEXT NOT NULL
);

CREATE TABLE books (
    book_id        TEXT PRIMARY KEY,
    title          TEXT NOT NULL,
    page_count     INTEGER NOT NULL,
    source_grade   TEXT NOT NULL,   -- 'أصلي' | 'ثانوي'
    source_code    TEXT NOT NULL,   -- 'primary' | 'secondary'  (ASCII-safe)
    source_tier    INTEGER NOT NULL CHECK (source_tier BETWEEN 1 AND 5),
    source_author  TEXT,
    source_note    TEXT,
    FOREIGN KEY (source_grade) REFERENCES grades(grade)
);

CREATE TABLE pages (
    id            INTEGER PRIMARY KEY,
    book_id       TEXT NOT NULL,
    seq           INTEGER NOT NULL,
    printed_page  TEXT,
    citation_label TEXT,
    qasida_number INTEGER,
    qasida_title TEXT,
    bayt_from INTEGER,
    bayt_to INTEGER,
    block_type TEXT NOT NULL DEFAULT 'body' CHECK (block_type IN ('body', 'toc')),
    text          TEXT NOT NULL,
    norm_text     TEXT NOT NULL,
    FOREIGN KEY (book_id) REFERENCES books(book_id)
);
CREATE INDEX idx_pages_book_seq ON pages(book_id, seq);
CREATE INDEX idx_pages_qasida ON pages(book_id, qasida_number, bayt_from);
CREATE INDEX idx_pages_block_type ON pages(block_type);

CREATE TABLE bayts (
    stable_id TEXT PRIMARY KEY,
    page_id INTEGER NOT NULL,
    book_id TEXT NOT NULL,
    qasida_number INTEGER NOT NULL,
    bayt_number INTEGER NOT NULL,
    start_char INTEGER NOT NULL,
    end_char INTEGER NOT NULL,
    text TEXT NOT NULL,
    norm_text TEXT NOT NULL,
    FOREIGN KEY (page_id) REFERENCES pages(id),
    UNIQUE (book_id, qasida_number, bayt_number)
);
CREATE INDEX idx_bayts_page ON bayts(page_id, start_char);
CREATE INDEX idx_bayts_structure ON bayts(book_id, qasida_number, bayt_number);

CREATE VIRTUAL TABLE pages_fts USING fts5(
    norm_text,
    content='pages',
    content_rowid='id',
    tokenize='unicode61 remove_diacritics 2'
);
"""


def slug_for(n: int) -> str:
    return f"b{n:02d}"


# A real Diwan heading is followed by its date.  Requiring that marker keeps
# prose such as "هذه القصيدة لها ثلاث قوافي: ..." from being mistaken for a
# new Qasida.  That note occurs after Qasida 4 in b14 and previously shifted
# every subsequent qasida_number by one (printed 62 was consequently indexed
# as 63).
_QASIDA_HEADING = re.compile(
    r"الْ?قَ?صِ?يدَ?ة\s+([^:\n]{1,80}):\s*([^\n]+?)"
    r"(?=\s+التّ?اريخ\s*:)"
)
_QASIDA_NUMERIC_DESIGNATOR = re.compile(
    r"^\s*(?:رقم\s*)?([0-9٠-٩۰-۹]{1,3})\s*$"
)
_DIGIT_TRANSLATION = str.maketrans(
    "٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹",
    "01234567890123456789",
)
_BAYT_NUMBER = re.compile(r"(?<![\d-])(\d{1,3})\s*-\s*(?=[\u0621-\u064A])")
_QASIDA_TITLE_END = re.compile(
    r"\s+التّ?اريخ\s*:|\s+\d{1,3}\s*-\s*(?=[ء-ي])"
)
_TOC_DOT_LEADER = re.compile(r"\.{5,}|…{3,}")


def classify_block(text: str) -> str:
    """Identify contents pages structurally instead of learning them from rank."""
    normalized = normalize_arabic(text, aggressive=True)
    if re.search(r"(?:^|\s)(?:الفهرس|فهرس المحتويات)(?:\s|$)", normalized):
        return "toc"
    return "toc" if len(_TOC_DOT_LEADER.findall(text)) >= 3 else "body"


def annotate_diwan_pages(pages: list[dict]) -> list[dict]:
    """Carry qasida and bayt structure across b14 page boundaries."""
    qasida_number, qasida_title, last_bayt = 0, None, None
    for page in pages:
        text = "\n\n".join(page["paragraphs"])
        heading = _QASIDA_HEADING.search(text)
        if heading:
            numeric = _QASIDA_NUMERIC_DESIGNATOR.fullmatch(heading.group(1))
            if numeric:
                # An explicit printed number is authoritative.  Do not feed
                # it through the sequential fallback: skipped single-digit
                # headings would otherwise shift every later qaṣīda.
                qasida_number = int(
                    numeric.group(1).translate(_DIGIT_TRANSLATION)
                )
            else:
                # Backward compatibility for older source files whose
                # headings use written Arabic ordinals.
                qasida_number += 1
            qasida_title = _QASIDA_TITLE_END.split(
                heading.group(2), maxsplit=1
            )[0].strip()
            last_bayt = None
        bayts = [int(n) for n in _BAYT_NUMBER.findall(text)]
        page["qasida_number"] = qasida_number or None
        page["qasida_title"] = qasida_title
        page["bayt_from"] = bayts[0] if bayts else last_bayt
        page["bayt_to"] = bayts[-1] if bayts else last_bayt
        page["block_type"] = classify_block(text)
        if bayts:
            last_bayt = bayts[-1]
        if qasida_number and page["bayt_from"] is not None:
            span = (f"البيت {page['bayt_from']}" if page["bayt_from"] == page["bayt_to"]
                    else f"الأبيات {page['bayt_from']}–{page['bayt_to']}")
            page["page_label"] = f"القصيدة {qasida_number}، {span}"
    return pages


def build():
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)

    mapping = json.load(open(MAPPING_FILE, encoding="utf-8"))
    sources = json.load(open(SOURCES_FILE, encoding="utf-8"))
    grades = sources["grades"]
    book_sources = sources["books"]
    book_tiers = sources["tiers"]["books"]
    tier_definitions = sources["tiers"]["definitions"]

    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA)

    for grade, g in grades.items():
        conn.execute(
            "INSERT INTO grades (grade, code, label, definition, usage) "
            "VALUES (?, ?, ?, ?, ?)",
            (grade, g["code"], g["label"], g["definition"], g["usage"]),
        )

    for tier, definition in tier_definitions.items():
        conn.execute(
            "INSERT INTO source_tiers (tier, definition) VALUES (?, ?)",
            (int(tier), definition),
        )

    missing: list[str] = []
    total_pages = 0

    for slug_in, title in sorted(mapping.items()):
        n = int(slug_in.split("_")[1])
        slug = slug_for(n)

        htm_path = os.path.join(RAW_DIR, f"{slug_in}.htm")
        utf8_path = os.path.join(RAW_UTF8_DIR, f"{slug_in}.json")
        if os.path.exists(htm_path):
            pages = parse_book(htm_path)
        elif os.path.exists(utf8_path):
            pages = parse_utf8_pages(utf8_path)
        else:
            # Neither source file exists for this mapping entry — treat
            # like any other missing book rather than crashing here, so
            # the loud error at the end lists everything wrong in one go.
            missing.append(f"{slug} (no {slug_in}.htm or {slug_in}.json found)")
            continue

        # Protect the API from pathological source records (notably b02,
        # whose source export has no real page markers). Ordinary pages are
        # unchanged; only oversized records are segmented.
        pages = split_oversized_pages(pages)
        if slug == "b14":
            pages = annotate_diwan_pages(pages)

        src = book_sources.get(slug)
        if src is None:
            # Fail loud rather than silently shipping an ungraded book:
            # an ungraded book is worse than a missing one, because the
            # model will treat it as if it had no provenance caveat.
            missing.append(slug)
            continue

        tier = book_tiers.get(slug)
        if not isinstance(tier, int) or not 1 <= tier <= 5:
            missing.append(f"{slug} (missing numeric source tier 1-5)")
            continue

        grade = src["grade"]
        if grade not in grades:
            raise SystemExit(f"{slug}: unknown grade '{grade}' — not in sources.json grades")

        conn.execute(
            "INSERT INTO books "
            "(book_id, title, page_count, source_grade, source_code, source_tier, source_author, source_note) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                slug,
                title,
                len(pages),
                grade,
                grades[grade]["code"],
                tier,
                src.get("author"),
                src.get("note"),
            ),
        )

        for seq, page in enumerate(pages, start=1):
            text = "\n\n".join(page["paragraphs"])
            norm = normalize_arabic(text, aggressive=True)
            conn.execute(
                "INSERT INTO pages (book_id, seq, printed_page, citation_label, qasida_number, "
                "qasida_title, bayt_from, bayt_to, block_type, text, norm_text) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (slug, seq, page["printed_page"], page.get("page_label"),
                 page.get("qasida_number"), page.get("qasida_title"),
                 page.get("bayt_from"), page.get("bayt_to"),
                 page.get("block_type", classify_block(text)), text, norm),
            )
            page_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            if slug == "b14" and page.get("qasida_number"):
                markers = list(_BAYT_NUMBER.finditer(text))
                for i, marker in enumerate(markers):
                    number = int(marker.group(1))
                    start = marker.start()
                    end = markers[i + 1].start() if i + 1 < len(markers) else len(text)
                    bayt_text = text[start:end].strip()
                    stable_id = f"{slug}-q{page['qasida_number']:03d}-b{number:03d}"
                    conn.execute(
                        "INSERT OR REPLACE INTO bayts (stable_id, page_id, book_id, qasida_number, "
                        "bayt_number, start_char, end_char, text, norm_text) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        (stable_id, page_id, slug, page["qasida_number"], number,
                         start, end, bayt_text, normalize_arabic(bayt_text, aggressive=True)),
                    )
        total_pages += len(pages)
        print(f"{slug}  [{grades[grade]['code']:<9}] {len(pages):4d} pages  {title}")

    if missing:
        raise SystemExit(
            "\nERROR: these books have no entry in data/sources.json: "
            + ", ".join(missing)
            + "\nAdd them (with a grade) before building."
        )

    # NOTE: only `pages` feeds the FTS index. Grades / notes / authors
    # deliberately stay out of it.
    conn.execute("INSERT INTO pages_fts(rowid, norm_text) SELECT id, norm_text FROM pages")
    conn.commit()
    conn.execute("PRAGMA optimize")
    conn.close()

    n_primary = sum(1 for s in book_sources.values() if s["grade"] == "أصلي")
    n_secondary = len(book_sources) - n_primary
    print(
        f"\nBuilt {DB_PATH} — {len(mapping)} books "
        f"({n_primary} primary / {n_secondary} secondary), {total_pages} pages"
    )


if __name__ == "__main__":
    build()
